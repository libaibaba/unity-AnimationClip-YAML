﻿using System;
using System.Runtime.InteropServices;

namespace Story.Data
{
	// Token: 0x02000002 RID: 2
	[Guid("3807710B-BEEE-4E01-80E8-CADF4D25A3AA")]
	public enum CommandCategory
	{
		// Token: 0x04000002 RID: 2
		Non,
		// Token: 0x04000003 RID: 3
		System,
		// Token: 0x04000004 RID: 4
		Motion,
		// Token: 0x04000005 RID: 5
		Effect
	}
}
