﻿using System;
using System.Runtime.InteropServices;

namespace Story.Data
{
	// Token: 0x02000005 RID: 5
	[InterfaceType(ComInterfaceType.InterfaceIsDual)]
	public interface ICommandConfig
	{
		// Token: 0x06000001 RID: 1
		void Init();

		// Token: 0x06000002 RID: 2
		int GetCommandID(ref string name);

		// Token: 0x06000003 RID: 3
		string GetCommandName(int id);

		// Token: 0x06000004 RID: 4
		string GetCommandSummary(int id);

		// Token: 0x06000005 RID: 5
		string GetCommandUsage(int id);

		// Token: 0x06000006 RID: 6
		int GetCommandConfigListCount();

		// Token: 0x06000007 RID: 7
		string GetSpacer();
	}
}
