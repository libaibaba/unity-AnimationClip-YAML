﻿namespace storydecode
{
	// Token: 0x02000008 RID: 8
	public partial class Form1 : global::System.Windows.Forms.Form
	{
		// Token: 0x0600001C RID: 28 RVA: 0x000037F0 File Offset: 0x000019F0
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x0600001D RID: 29 RVA: 0x00003828 File Offset: 0x00001A28
		private void InitializeComponent()
		{
            this.decode = new System.Windows.Forms.Button();
            this.encode = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // decode
            // 
            this.decode.Location = new System.Drawing.Point(12, 12);
            this.decode.Name = "decode";
            this.decode.Size = new System.Drawing.Size(75, 23);
            this.decode.TabIndex = 0;
            this.decode.Text = "Decode";
            this.decode.UseVisualStyleBackColor = true;
            this.decode.Click += new System.EventHandler(this.decode_Click);
            // 
            // encode
            // 
            this.encode.Location = new System.Drawing.Point(93, 12);
            this.encode.Name = "encode";
            this.encode.Size = new System.Drawing.Size(75, 23);
            this.encode.TabIndex = 1;
            this.encode.Text = "Encode";
            this.encode.UseVisualStyleBackColor = true;
            this.encode.Click += new System.EventHandler(this.encode_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(194, 66);
            this.Controls.Add(this.encode);
            this.Controls.Add(this.decode);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

		}

		// Token: 0x04000016 RID: 22
		private global::System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.Button decode;
        private System.Windows.Forms.Button encode;
    }
}
