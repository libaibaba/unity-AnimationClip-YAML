﻿using System;
using System.Windows.Forms;

namespace storydecode
{
	// Token: 0x0200000B RID: 11
	internal static class Program
	{
		// Token: 0x06000037 RID: 55 RVA: 0x0000455C File Offset: 0x0000275C
		[STAThread]
		private static void Main()
		{
			Application.EnableVisualStyles();
			Application.SetCompatibleTextRenderingDefault(false);
			Application.Run(new Form1());
		}
	}
}
