﻿using System;
using System.Runtime.InteropServices;

namespace Story.Data
{
	// Token: 0x02000009 RID: 9
	[Guid("DDA224F0-5F93-4F3C-9D65-0F0204B76DC0")]
	[InterfaceType(ComInterfaceType.InterfaceIsDual)]
	public interface IParser
	{
		// Token: 0x0600001E RID: 30
		void ConvertStoryDataTextToBinary(ref string srcPath, ref string dstPath);

		// Token: 0x0600001F RID: 31
		void Init();
	}
}
