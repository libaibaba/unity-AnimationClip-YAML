﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;

namespace Story.Data
{
	// Token: 0x02000006 RID: 6
	[ClassInterface(ClassInterfaceType.None)]
	[ComDefaultInterface(typeof(ICommandConfig))]
	[ComVisible(true)]
	public class Config : ICommandConfig
	{
		// Token: 0x06000008 RID: 8 RVA: 0x00002050 File Offset: 0x00000250
		public static Config Create()
		{
			Config config = new Config();
			config.Init();
			return config;
		}

		// Token: 0x06000009 RID: 9 RVA: 0x00002070 File Offset: 0x00000270
		public void Init()
		{
			this._commandConfigList = new List<CommandConfig>();
			//0
			this.RegisterCommandConfig("title", "标题设置", "title <标题>", "Title", CommandCategory.System, 1, 1);
			//1
			this.RegisterCommandConfig("outline", "概要设定", "outline <剧情简介>", "Outline", CommandCategory.System, 1, 1);
			//2
			this.RegisterCommandConfig("chara", "添加角色", "chara <キャラID> <L:左, LC:左寄り, C:真ん中, RC:右寄り, R:右> <タイプID> <表情ID>", "Chara", CommandCategory.System, 4, 4);
			//3
			this.RegisterCommandConfig("visible", "角色显示切换", "visible <キャラID> <true か false>", "Visible", CommandCategory.System, 2, 2);
			//4
			this.RegisterCommandConfig("type", "角色类型切换", "type <キャラID> <タイプID>", "Type", CommandCategory.System, 2, 2);
			//5
			this.RegisterCommandConfig("face", "角色表情", "face <キャラID> <表情ID> <タイプID:オプション> <オフセットX:オプション> <オフセットY:オプション>", "Face", CommandCategory.System, 2, 5);
			//6
			this.RegisterCommandConfig("focus", "亮显角色", "focus <キャラID>", "Focus", CommandCategory.System, 1, 1);
			//7
			this.RegisterCommandConfig("background", "背景设定", "background <背景ID もしくは カードID>", "Background", CommandCategory.System, 1, 1);
			//8
			this.RegisterCommandConfig("print", "文本显示", "pring <名前> <テキスト>", "Print", CommandCategory.System, 2, 2);
			//9
			this.RegisterCommandConfig("tag", "标记设置", "tag <タグID>", "Tag", CommandCategory.System, 1, 1);
			//10
			this.RegisterCommandConfig("goto", "移动到指定标记的位置", "goto <飛ばしたいタグID>", "Goto", CommandCategory.System, 1, 1);
			//11
			this.RegisterCommandConfig("bgm", "BGM指定", "bgm <キュー名>", "Bgm", CommandCategory.System, 1, 2);
			//12
			this.RegisterCommandConfig("touch", "等待触摸输入", "touch", "Touch", CommandCategory.System, 0, 0);
			//13
			this.RegisterCommandConfig("choice", "添加选项", "choice <選択肢ラベル> <飛ばしたいタグID>", "Choice", CommandCategory.System, 2, 2);
			//14
			this.RegisterCommandConfig("vo", "播放声音", "vo <ボイスキュー名>", "Vo", CommandCategory.System, 1, 1);
			//15
			this.RegisterCommandConfig("wait", "等待指定时间", "wait <待ち時間>", "Wait", CommandCategory.System, 1, 1);
			//16
			this.RegisterCommandConfig("in_L", "从左进入", "in_L <キャラID> <フレーム数:オプション> <フェードフラグ:オプション>", "InL", CommandCategory.Motion, 1, 3);
			//17
			this.RegisterCommandConfig("in_R", "从右进入>", "in_R <キャラID> <フレーム数:オプション> <フェードフラグ:オプション>", "InR", CommandCategory.Motion, 1, 3);
			//18
			this.RegisterCommandConfig("out_L", "向左滑出", "out_L <キャラID> <フレーム数:オプション> <フェードフラグ:オプション>", "OutL", CommandCategory.Motion, 1, 3);
			//19
			this.RegisterCommandConfig("out_R", "向右滑出", "out_R <キャラID> <フレーム数:オプション> <フェードフラグ:オプション>", "OutR", CommandCategory.Motion, 1, 3);
			//20
			this.RegisterCommandConfig("fadein", "淡入>", "fadein <キャラID> <フレーム数:オプション>", "Fadein", CommandCategory.Motion, 1, 2);
			//21
			this.RegisterCommandConfig("fadeout", "淡出", "fadeout <キャラID> <フレーム数:オプション>", "Fadeout", CommandCategory.Motion, 0, 2);
			//22
			this.RegisterCommandConfig("in_float", "フロートイン", "in_float <キャラID> <フレーム数:オプション>", "InFloat", CommandCategory.Motion, 1, 2);
			//23
			this.RegisterCommandConfig("out_float", "フロートアウト", "out_float <キャラID> <フレーム数:オプション>", "OutFloat", CommandCategory.Motion, 1, 2);
			//24
			this.RegisterCommandConfig("jump", "跳跃", "jump <キャラID> <回数:オプション>", "Jump", CommandCategory.Motion, 1, 2);
			//25
			this.RegisterCommandConfig("shake", "颤动", "shake <キャラID> <回数:オプション>", "Shake", CommandCategory.Motion, 1, 2);
			//26
			this.RegisterCommandConfig("pop", "轻轻地弹", "pop <キャラID> <回数:オプション>", "Pop", CommandCategory.Motion, 1, 2);
			//27
			this.RegisterCommandConfig("nod", "沉没", "nod <キャラID> <回数:オプション>", "Nod", CommandCategory.Motion, 1, 2);
			//28
			this.RegisterCommandConfig("question_right", "はてな\u3000右向き", "question_right <キャラID>", "QuestionRight", CommandCategory.Motion, 1, 1);
			//29
			this.RegisterCommandConfig("question_left", "はてな\u3000左向き", "question_left <キャラID>", "QuestionLeft", CommandCategory.Motion, 1, 1);
			//30
			this.RegisterCommandConfig("se", "SE再生", "se <キューシート> <キュー名>", "Se", CommandCategory.System, 1, 2);
			//31
			this.RegisterCommandConfig("black_out", "暗出", "black_out <アルファ:オプション> <時間:オプション>", "BlackOut", CommandCategory.System, 0, 2);
			//32
			this.RegisterCommandConfig("black_in", "暗入", "black_in", "BlackIn", CommandCategory.System, 0, 2);
			//33
			this.RegisterCommandConfig("white_out", "白出", "white_out <アルファ:オプション> <時間:オプション>", "WhiteOut", CommandCategory.System, 0, 2);
			//34
			this.RegisterCommandConfig("white_in", "白入", "white_in", "WhiteIn", CommandCategory.System, 0, 2);
			//35
			this.RegisterCommandConfig("transition", "场面转换演出", "transition <アニメ名:オプション>", "Transition", CommandCategory.System, 0, 1);
			//36
			this.RegisterCommandConfig("situation", "带显示指定字符串", "situation <場面名>", "Situation", CommandCategory.System, 1, 1);
			//37
			this.RegisterCommandConfig("color_fadein", "指定颜色淡入", "color_fadein <RGBコード> <透明度> <時間>", "ColorFadein", CommandCategory.System, 3, 3);
			//38
			this.RegisterCommandConfig("flash", "フラッシュ", "flash", "Flash", CommandCategory.System, 0, 0);
			//39
			this.RegisterCommandConfig("shake_text", "テキストウィンドウを揺らす", "shake_text", "ShakeText", CommandCategory.System, 0, 0);
			//40
			this.RegisterCommandConfig("text_size", "フォントサイズ指定", "text_size <フォントサイズ>", "TextSize", CommandCategory.System, 1, 1);
			//41
			this.RegisterCommandConfig("shake_screen", "画面全体揺らす", "shake_screen", "ShakeScreen", CommandCategory.System, 0, 0);
			//42
			this.RegisterCommandConfig("double", "テキストを重ねて表示", "double <名前> <テキスト> <オフセットX:オプション> <オフセットY:オプション>", "Double", CommandCategory.System, 2, 4);
			//43
			this.RegisterCommandConfig("flower_y", "黄色の花びら", "flower_y <キャラID> <オフセットX:オプション> <オフセットY:オプション>", "FlowerY", CommandCategory.Effect, 1, 3);
			//44
			this.RegisterCommandConfig("flower_r", "赤い花びら", "flower_r <キャラID> <オフセットX:オプション> <オフセットY:オプション>", "FlowerR", CommandCategory.Effect, 1, 3);
			//45
			this.RegisterCommandConfig("concent", "集中線", "concent <キャラID> <オフセットX:オプション> <オフセットY:オプション>", "Concent", CommandCategory.Effect, 1, 3);
			//46
			this.RegisterCommandConfig("find_l", "気付(左)", "find_l <キャラID> <オフセットX:オプション> <オフセットY:オプション>", "FindL", CommandCategory.Effect, 1, 3);
			//47
			this.RegisterCommandConfig("find_r", "気付き(右)", "find_r <キャラID> <オフセットX:オプション> <オフセットY:オプション>", "FindR", CommandCategory.Effect, 1, 3);
			//48
			this.RegisterCommandConfig("laugh_l", "笑い三本線(左)", "laugh_l <キャラID> <オフセットX:オプション> <オフセットY:オプション>", "LaughL", CommandCategory.Effect, 1, 3);
			//49
			this.RegisterCommandConfig("laugh_r", "笑い三本線(右)", "laugh_r <キャラID> <オフセットX:オプション> <オフセットY:オプション>", "LaughR", CommandCategory.Effect, 1, 3);
			//50
			this.RegisterCommandConfig("chord_l", "音符(左)", "chord_l <キャラID> <オフセットX:オプション> <オフセットY:オプション>", "ChordL", CommandCategory.Effect, 1, 3);
			//51
			this.RegisterCommandConfig("chord_r", "音符(右)", "chord_r <キャラID> <オフセットX:オプション> <オフセットY:オプション>", "ChordR", CommandCategory.Effect, 1, 3);
			//52
			this.RegisterCommandConfig("sweat_l", "汗(左)", "sweat_l <キャラID> <オフセットX:オプション> <オフセットY:オプション>", "SweatL", CommandCategory.Effect, 1, 3);
			//53
			this.RegisterCommandConfig("sweat_r", "汗(右)", "sweat_r <キャラID> <オフセットX:オプション> <オフセットY:オプション>", "SweatR", CommandCategory.Effect, 1, 3);
			//54
			this.RegisterCommandConfig("question_l", "はてな(左)", "question_l <キャラID> <オフセットX:オプション> <オフセットY:オプション>", "QuestionL", CommandCategory.Effect, 1, 3);
			//55
			this.RegisterCommandConfig("question_r", "はてな(右)", "question_r <キャラID> <オフセットX:オプション> <オフセットY:オプション>", "QuestionR", CommandCategory.Effect, 1, 3);
			//56
			this.RegisterCommandConfig("angry", "ぷんすか(左)", "angry <キャラID> <オフセットX:オプション> <オフセットY:オプション>", "Angry", CommandCategory.Effect, 1, 3);
			//57
			this.RegisterCommandConfig("drop_l", "汗2(左)", "drop_l <キャラID> <オフセットX:オプション> <オフセットY:オプション>", "DropL", CommandCategory.Effect, 1, 3);
			//58
			this.RegisterCommandConfig("drop_r", "汗2(右)", "drop_r <キャラID> <オフセットX:オプション> <オフセットY:オプション>", "DropR", CommandCategory.Effect, 1, 3);
			//59
			this.RegisterCommandConfig("live", "ライブ遷移", "live <楽曲ID> <難易度(debut:1から数字上がる毎に難易度アップ)> <メンバー1ID> <メンバー2ID> <メンバー3ID> <メンバー4ID> <メンバー5ID> <観客フラグ:オプション>", "Live", CommandCategory.System, 7, 8);
			//60
			this.RegisterCommandConfig("scale", "拡縮", "scale <キャラID> <拡縮率(等倍は1)>", "Scale", CommandCategory.Motion, 2, 2);
			//61
			this.RegisterCommandConfig("title_telop", "タイトルテロップ", "title_telop <ストーリーID>", "TitleTelop", CommandCategory.System, 1, 1);
			//62
			this.RegisterCommandConfig("window_visible", "テキストウィンドウの表示切り替え", "window_visible <\"true\" か \"false\">", "WindowVisible", CommandCategory.System, 1, 1);
			//63
			this.RegisterCommandConfig("log", "ログにだけ表示するテキスト", "log <キャラID> <名前> <テキスト> <ボイスID : オプション>", "Log", CommandCategory.System, 3, 4);
			//64
			this.RegisterCommandConfig("novoice", "ボイス再生しない", "novoice", "NoVoice", CommandCategory.System, 0, 0);
			//65
			this.RegisterCommandConfig("attract", "話している人", "attract <キャラID>", "Attract", CommandCategory.System, 1, 1);
			//66
			this.RegisterCommandConfig("change", "キャラ位置入れ替え", "change <位置1> <位置2> <移動フレーム数:オプション>", "Change", CommandCategory.Motion, 2, 3);
			//67
			this.RegisterCommandConfig("fadeout_all", "キャラとウィンドウを消す", "fadeout_all <フェード時間(フレーム)>", "FadeoutAll", CommandCategory.System, 0, 1);
		}

		// Token: 0x0600000A RID: 10 RVA: 0x00002884 File Offset: 0x00000A84
		private void RegisterCommandConfig(string name, string summary, string usage, string className, CommandCategory category, int minArgCount, int maxArgCount)
		{
			int count = this._commandConfigList.Count;
			CommandConfig item = default(CommandConfig);
			item.ID = count - 1;
			item.Name = name;
			item.Summary = summary;
			item.Usage = usage;
			item.ClassName = className;
			item.Category = category;
			item.MinArgCount = minArgCount;
			item.MaxArgCount = maxArgCount;
			this._commandConfigList.Add(item);
		}

		// Token: 0x0600000B RID: 11 RVA: 0x000028FC File Offset: 0x00000AFC
		public int GetCommandID(ref string name)
		{
			int count = this._commandConfigList.Count;
			for (int i = 0; i < count; i++)
			{
				if (this._commandConfigList[i].Name.Equals(name))
				{
					return i;
				}
			}
			return -1;
		}

		// Token: 0x0600000C RID: 12 RVA: 0x00002954 File Offset: 0x00000B54
		public string GetCommandName(int id)
		{
			string result;
			if (id >= this._commandConfigList.Count | id < 0)
			{
				result = null;
			}
			else
			{
				result = this._commandConfigList[id].Name;
			}
			return result;
		}

		// Token: 0x0600000D RID: 13 RVA: 0x0000299C File Offset: 0x00000B9C
		public string GetCommandSummary(int id)
		{
			string result;
			if (id >= this._commandConfigList.Count | id < 0)
			{
				result = null;
			}
			else
			{
				result = this._commandConfigList[id].Summary;
			}
			return result;
		}

		// Token: 0x0600000E RID: 14 RVA: 0x000029E4 File Offset: 0x00000BE4
		public string GetCommandUsage(int id)
		{
			string result;
			if (id >= this._commandConfigList.Count | id < 0)
			{
				result = null;
			}
			else
			{
				result = this._commandConfigList[id].Usage;
			}
			return result;
		}

		// Token: 0x0600000F RID: 15 RVA: 0x00002A2C File Offset: 0x00000C2C
		public string GetCommandClassName(int id)
		{
			string result;
			if (id >= this._commandConfigList.Count | id < 0)
			{
				result = null;
			}
			else
			{
				result = this._commandConfigList[id].ClassName;
			}
			return result;
		}

		// Token: 0x06000010 RID: 16 RVA: 0x00002A74 File Offset: 0x00000C74
		public CommandCategory GetCommandCategory(int id)
		{
			CommandCategory result;
			if (id >= this._commandConfigList.Count | id < 0)
			{
				result = CommandCategory.Non;
			}
			else
			{
				result = this._commandConfigList[id].Category;
			}
			return result;
		}

		// Token: 0x06000011 RID: 17 RVA: 0x00002ABC File Offset: 0x00000CBC
		public int GetCommandMinArgCount(int id)
		{
			int result;
			if (id >= this._commandConfigList.Count | id < 0)
			{
				result = 0;
			}
			else
			{
				result = this._commandConfigList[id].MinArgCount;
			}
			return result;
		}

		// Token: 0x06000012 RID: 18 RVA: 0x00002B04 File Offset: 0x00000D04
		public int GetCommandMaxArgCount(int id)
		{
			int result;
			if (id >= this._commandConfigList.Count | id < 0)
			{
				result = 0;
			}
			else
			{
				result = this._commandConfigList[id].MaxArgCount;
			}
			return result;
		}

		// Token: 0x06000013 RID: 19 RVA: 0x00002B4C File Offset: 0x00000D4C
		public int GetCommandConfigListCount()
		{
			return this._commandConfigList.Count;
		}

		// Token: 0x06000014 RID: 20 RVA: 0x00002B6C File Offset: 0x00000D6C
		public string GetSpacer()
		{
			return char.ToString(' ');
		}

		// Token: 0x04000011 RID: 17
		private List<CommandConfig> _commandConfigList;
	}
}
