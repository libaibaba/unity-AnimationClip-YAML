﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;

namespace Story.Data
{
	// Token: 0x02000006 RID: 6
	[ClassInterface(ClassInterfaceType.None)]
	[ComDefaultInterface(typeof(ICommandConfig))]
	[ComVisible(true)]
	public class Config1 : ICommandConfig
	{
		// Token: 0x06000008 RID: 8 RVA: 0x00002050 File Offset: 0x00000250
		public static Config1 Create()
		{
			Config1 config = new Config1();
			config.Init();
			return config;
		}

		// Token: 0x06000009 RID: 9 RVA: 0x00002070 File Offset: 0x00000270
		public void Init()
		{
			this._commandConfigList = new List<CommandConfig>();
			//0
			this.RegisterCommandConfig("title", "标题设置", "title <标题>", "Title", CommandCategory.System, 1, 1);
			//1
			this.RegisterCommandConfig("outline", "概要设定", "outline <剧情简介>", "Outline", CommandCategory.System, 1, 1);
			//2
			this.RegisterCommandConfig("chara", "添加角色", "chara <キャラID> <L:左, LC:左寄り, C:真ん中, RC:右寄り, R:右> <タイプID> <表情ID>", "Chara", CommandCategory.System, 4, 4);
			//3
			 this.RegisterCommandConfig("face", "角色表情", "face <キャラID> <表情ID> <タイプID:オプション> <オフセットX:オプション> <オフセットY:オプション>", "Face", CommandCategory.System, 2, 5);
			//4
			this.RegisterCommandConfig("focus", "亮显角色", "focus <ID or ID:ID >", "Focus", CommandCategory.System, 1, 1);
			//5
			this.RegisterCommandConfig("background", "背景设定", "background <背景ID もしくは カードID>", "Background", CommandCategory.System, 1, 1);
			//6
			this.RegisterCommandConfig("print", "文本显示", "pring <名前> <テキスト>", "Print", CommandCategory.System, 2, 2);
			//7
			this.RegisterCommandConfig("choiceto", "分支走向", "choiceto <ID> ", "choiceto", CommandCategory.System, 1, 1);
			//8
			this.RegisterCommandConfig("1p1rint", "文本显示", "pring <名前> <テキスト>", "1P1rint", CommandCategory.System, 2, 2);
			//9
			this.RegisterCommandConfig("bgm", "BGM指定", "bgm <キュー名>", "Bgm", CommandCategory.System, 1, 9);
			//10
			 this.RegisterCommandConfig("touch", "等待触摸输入", "touch", "Touch", CommandCategory.System, 0, 0);
			//11
			 this.RegisterCommandConfig("choice", "添加选项", "choice <選択肢ラベル> <飛ばしたいタグID>", "Choice", CommandCategory.System, 1, 3);
			//12
			 this.RegisterCommandConfig("vo", "播放声音", "vo <ボイスキュー名>", "Vo", CommandCategory.System, 1, 1);
			//13
			this.RegisterCommandConfig("wait", "等待指定时间", "wait <待ち時間>", "Wait", CommandCategory.System, 1, 1);
			//14
			this.RegisterCommandConfig("flower_r", "赤い花びら", "flower_r <キャラID> <オフセットX:オプション> <オフセットY:オプション>", "FlowerR", CommandCategory.Effect, 1, 3);
			//15
			this.RegisterCommandConfig("bgm", "BGM指定", "bgm <キュー名>", "Bgm", CommandCategory.System, 1, 2);
			//16
			this.RegisterCommandConfig("in_L", "从左进入", "in_L <キャラID> <帧数：选项> <フェードフラグ:オプション>", "InL", CommandCategory.Motion, 1, 3);
			//17
			this.RegisterCommandConfig("in_R", "从右进入>", "in_R <キャラID> <フレーム数:オプション> <フェードフラグ:オプション>", "InR", CommandCategory.Motion, 1, 3);
			//18
			this.RegisterCommandConfig("fadein", "淡入>", "fadein <ID> <位置>", "Fadein", CommandCategory.Motion, 1, 2);
			//19
			 this.RegisterCommandConfig("fadeout", "淡出", "fadeout <キャラID> <フレーム数:オプション>", "Fadeout", CommandCategory.Motion, 0, 2);
			//20
			this.RegisterCommandConfig("out_L", "向左滑出", "out_L <キャラID> <フレーム数:オプション> <フェードフラグ:オプション>", "OutL", CommandCategory.Motion, 1, 3);
			//21
			this.RegisterCommandConfig("out_R", "向右滑出", "out_R <キャラID> <フレーム数:オプション> <フェードフラグ:オプション>", "OutR", CommandCategory.Motion, 1, 3);
			//22
			this.RegisterCommandConfig("jumps", "跳跃", "in_float <ID> <回数>", "jumps", CommandCategory.Motion, 1, 2);
			//23
			this.RegisterCommandConfig("out_float", "フロートアウト", "out_float <キャラID> <フレーム数:オプション>", "OutFloat", CommandCategory.Motion, 1, 2);
			//24
			this.RegisterCommandConfig("shake", "颤动", "shake <ID>", "Shake", CommandCategory.Motion, 1, 2);
			//25
			this.RegisterCommandConfig("jump", "跳跃", "jump <ID>", "Jump", CommandCategory.Motion, 0, 2);
			//26
			this.RegisterCommandConfig("se", "SE再生", "se <キューシート> <キュー名>", "Se", CommandCategory.System, 1, 2);
			//27
			this.RegisterCommandConfig("nod", "沉没", "nod <キャラID> <回数:オプション>", "Nod", CommandCategory.Motion, 1, 2);
			//28
			this.RegisterCommandConfig("question_right", "はてな\u3000右向き", "question_right <キャラID>", "QuestionRight", CommandCategory.Motion, 0, 1);
			//29
			this.RegisterCommandConfig("question_left", "はてな\u3000左向き", "question_left <キャラID>", "QuestionLeft", CommandCategory.Motion, 1, 2);
			//30
			this.RegisterCommandConfig("pop", "轻轻地弹", "pop <キャラID> <回数:オプション>", "Pop", CommandCategory.Motion, 0, 2);
			//31
			this.RegisterCommandConfig("black_out", "暗出", "black_out <アルファ:オプション> <時間:オプション>", "BlackOut", CommandCategory.System, 0, 2);
			//32
			this.RegisterCommandConfig("fulltitle", "开头的横幅", "black_in", "fulltitle", CommandCategory.System, 1, 1);
			//33
			this.RegisterCommandConfig("white_out", "白出", "white_out <アルファ:オプション> <時間:オプション>", "WhiteOut", CommandCategory.System, 0, 2);
			//34
			this.RegisterCommandConfig("white_in", "白入", "white_in", "WhiteIn", CommandCategory.System, 0, 2);
			//35
			this.RegisterCommandConfig("situation", "带显示指定字符串", "situation <場面名>", "Situation", CommandCategory.System, 1, 1);
			//36
			this.RegisterCommandConfig("transition", "场面转换演出", "transition <アニメ名:オプション>", "Transition", CommandCategory.System, 0, 1);
			//37
			this.RegisterCommandConfig("color_fadein", "指定颜色淡入", "color_fadein <RGBコード> <透明度> <時間>", "ColorFadein", CommandCategory.System, 0, 0);
			//38
			this.RegisterCommandConfig("flash", "フラッシュ", "flash", "Flash", CommandCategory.System, 0, 0);
			//39
			this.RegisterCommandConfig("goto1", "移动立绘", "移动立绘 <ID> <放大系数> <num?>", "goto1", CommandCategory.System, 0, 4);
			//40
			this.RegisterCommandConfig("text_size", "フォントサイズ指定", "text_size <フォントサイズ>", "TextSize", CommandCategory.System, 1, 1);
			//41
			this.RegisterCommandConfig("window_visible", "切换文本窗口", "window_visible <\"true\" か \"false\">", "WindowVisible", CommandCategory.System, 1, 1);
			//42
			this.RegisterCommandConfig("double", "テキストを重ねて表示", "double <名前> <テキスト> <オフセットX:オプション> <オフセットY:オプション>", "Double", CommandCategory.System, 2, 4);
			//43
			this.RegisterCommandConfig("flower_y", "黄色の花びら", "flower_y <キャラID> <オフセットX:オプション> <オフセットY:オプション>", "FlowerY", CommandCategory.Effect, 1, 3);
			//44
			 this.RegisterCommandConfig("goto", "移动到指定标记的位置", "goto <R C RC LC ← R C RC LC> <num 应该是速度>", "Goto", CommandCategory.System, 1, 3);
			//45
			this.RegisterCommandConfig("concent", "集中線", "concent <キャラID> <オフセットX:オプション> <オフセットY:オプション>", "Concent", CommandCategory.Effect, 1, 3);
			//46
			this.RegisterCommandConfig("usm", "usm视频", "usm视频 <ID> ", "usm", CommandCategory.System, 1, 1);
			//47
			this.RegisterCommandConfig("find_l", "気付(左)", "find_l <キャラID> <オフセットX:オプション> <オフセットY:オプション>", "FindL", CommandCategory.Effect, 1, 3);
			//48
			this.RegisterCommandConfig("laugh_l", "笑い三本線(左)", "laugh_l <キャラID> <オフセットX:オプション> <オフセットY:オプション>", "LaughL", CommandCategory.Effect, 1, 3);
			//49
			this.RegisterCommandConfig("laugh_r", "笑い三本線(右)", "laugh_r <キャラID> <オフセットX:オプション> <オフセットY:オプション>", "LaughR", CommandCategory.Effect, 1, 3);
			//50
			 this.RegisterCommandConfig("window_option", "角色对话框和设置左下方立绘", "window_option <ID> <0 or 1 就是bool>", "window_option", CommandCategory.System, 2, 2);
			//51
			this.RegisterCommandConfig("amb", "amb是啥", "amb", "amb", CommandCategory.System, 1, 1);
			//52
			this.RegisterCommandConfig("sweat_l", "汗(左)", "sweat_l <キャラID> <オフセットX:オプション> <オフセットY:オプション>", "SweatL", CommandCategory.Effect, 1, 3);
			//53
			this.RegisterCommandConfig("sweat_r", "汗(右)", "sweat_r <キャラID> <オフセットX:オプション> <オフセットY:オプション>", "SweatR", CommandCategory.Effect, 1, 3);
			//54
			this.RegisterCommandConfig("Effect", "特效吗", "Effect <ID> <name> <float>", "Effect", CommandCategory.Effect, 1, 9);
			//55
			this.RegisterCommandConfig("dellEffect", "删除特效吗", "dellEffect <キャラID>", "dellEffect", CommandCategory.Effect, 1, 3);
			//56
			this.RegisterCommandConfig("duihuakuangyao", "对话框摇晃", "duihuakuangyao <true or false>", "duihuakuangyao", CommandCategory.System, 1, 1);
			//57
			this.RegisterCommandConfig("drop_l", "汗2(左)", "drop_l <キャラID> <オフセットX:オプション> <オフセットY:オプション>", "DropL", CommandCategory.Effect, 1, 3);
			//58
			this.RegisterCommandConfig("drop_r", "汗2(右)", "drop_r <キャラID> <オフセットX:オプション> <オフセットY:オプション>", "DropR", CommandCategory.Effect,0, 3);
			//59
			this.RegisterCommandConfig("renwuEffect", "人物的表情特效", "人物的表情特效", "renwuEffect", CommandCategory.System, 0, 8);
			//60
			this.RegisterCommandConfig("scale", "拡縮", "scale <キャラID> <拡縮率(等倍は1)>", "Scale", CommandCategory.Motion, 1, 2);
			//61
			this.RegisterCommandConfig("title_telop", "标题触发器", "title_telop <ストーリーID>", "TitleTelop", CommandCategory.System, 1, 1);
			//62
			this.RegisterCommandConfig("shake_screen", "摇动整个画面", "shake_screen", "ShakeScreen", CommandCategory.System, 0, 0);
			//63
			this.RegisterCommandConfig("log", "仅在日志中显示的文本", "log <キャラID> <名前> <テキスト> <ボイスID : オプション>", "Log", CommandCategory.System, 3, 4);
			//64
			this.RegisterCommandConfig("novoice", "不播放声音", "novoice", "NoVoice", CommandCategory.System, 0, 0);
			//65
			this.RegisterCommandConfig("attract", "说话的人", "attract <キャラID>", "Attract", CommandCategory.System, 1, 1);
			//66
			this.RegisterCommandConfig("change", "角色位置替换", "change <位置1> <位置2> <移動フレーム数:オプション>", "Change", CommandCategory.Motion, 2, 3);
			//67
			this.RegisterCommandConfig("67", "特殊SE", "special_se <se_name> <num>", "67", CommandCategory.System, 1, 9);
			//68
			this.RegisterCommandConfig("Cwei", "角色位置", "C位 <ID> <L or R or C or LC or RC> <num 表情>", "Cwei", CommandCategory.System, 1, 9);
			//69
			this.RegisterCommandConfig("69", "特殊SE", "special_se <se_name> <num>", "69", CommandCategory.System, 1, 9);
			//70
			this.RegisterCommandConfig("screen_color", "屏幕全白", "color <num> <num> <num>", "screen_color", CommandCategory.System, 1, 3);
			//71
			this.RegisterCommandConfig("71", "特殊SE", "special_se <se_name> <num>", "71", CommandCategory.System, 1, 9);
			//72
			this.RegisterCommandConfig("big_character", "大立绘", "character <num>", "big_character", CommandCategory.System, 1, 9);
			//73
			this.RegisterCommandConfig("73", "特殊SE", "special_se <se_name> <num>", "73", CommandCategory.System, 1, 9);
			//74
			this.RegisterCommandConfig("74", "特殊SE", "special_se <se_name> <num>", "74", CommandCategory.System, 1, 9);
			//75
			this.RegisterCommandConfig("75", "特殊SE", "special_se <se_name> <num>", "75", CommandCategory.System, 0, 0);
			//76
			this.RegisterCommandConfig("76", "特殊SE", "special_se <se_name> <num>", "76", CommandCategory.System, 0, 0);
			//77
			this.RegisterCommandConfig("77", "特殊SE", "special_se <se_name> <num>", "77", CommandCategory.System, 0, 0);
			//78
			this.RegisterCommandConfig("78", "特殊SE", "special_se <se_name> <num>", "78", CommandCategory.System, 1, 9);
			//79
			this.RegisterCommandConfig("79", "特殊SE", "special_se <se_name> <num>", "79", CommandCategory.System, 1, 9);
			//80
			this.RegisterCommandConfig("80", "特殊SE", "special_se <se_name> <num>", "80", CommandCategory.System, 1, 9);
			//81
			this.RegisterCommandConfig("neixindubai", "应该是内心独白时候背景变暗的", "neixindubai <num> <%>", "neixindubai", CommandCategory.System, 1, 9);
			//82
			this.RegisterCommandConfig("82", "特殊SE", "special_se <se_name> <num>", "82", CommandCategory.System, 1, 9);
			//83
			this.RegisterCommandConfig("83", "特殊SE", "special_se <se_name> <num>", "83", CommandCategory.System, 1, 9);
			//84
			this.RegisterCommandConfig("zhayan", "眨眼的感觉?反正立绘消失了一下", "zhayan <num>", "zhayan", CommandCategory.System, 1, 9);
			//85
			this.RegisterCommandConfig("duihuakuangshezhi", "对话框设置", "duihuakuangshezhi <num> 1:普通 2:气泡 3:炸裂", "85", CommandCategory.System, 1, 9);
			//86
			this.RegisterCommandConfig("86", "特殊SE", "special_se <se_name> <num>", "86", CommandCategory.System, 1, 9);
			//87
			this.RegisterCommandConfig("87", "特殊SE", "special_se <se_name> <num>", "87", CommandCategory.System, 1, 9);
			//88
			this.RegisterCommandConfig("88", "特殊SE", "special_se <se_name> <num>", "88", CommandCategory.System, 1, 9);
			//89
			this.RegisterCommandConfig("89", "特殊SE", "special_se <se_name> <num>", "89", CommandCategory.System, 1, 9);
			//90
			this.RegisterCommandConfig("90", "特殊SE", "special_se <se_name> <num>", "90", CommandCategory.System, 1, 9);
			//91
			this.RegisterCommandConfig("91", "特殊SE", "special_se <se_name> <num>", "91", CommandCategory.System, 1, 9);
			//92
			this.RegisterCommandConfig("92", "特殊SE", "special_se <se_name> <num>", "92", CommandCategory.System, 1, 9);
			//93
			this.RegisterCommandConfig("93", "特殊SE", "special_se <se_name> <num>", "93", CommandCategory.System, 1, 9);
			//94
			this.RegisterCommandConfig("94", "特殊SE", "special_se <se_name> <num>", "94", CommandCategory.System, 1, 9);
			//95
			this.RegisterCommandConfig("95", "特殊SE", "special_se <se_name> <num>", "95", CommandCategory.System, 1, 9);
			//96
			this.RegisterCommandConfig("96", "特殊SE", "special_se <se_name> <num>", "96", CommandCategory.System, 1, 9);
			//97
			this.RegisterCommandConfig("97", "特殊SE", "special_se <se_name> <num>", "97", CommandCategory.System, 1, 9);
			//98
			this.RegisterCommandConfig("98", "特殊SE", "special_se <se_name> <num>", "98", CommandCategory.System, 1, 9);
			//99
			this.RegisterCommandConfig("99", "特殊SE", "special_se <se_name> <num>", "99", CommandCategory.System, 1, 9);
			//100
			this.RegisterCommandConfig("changjing_title", "左上角场景标题", "changjing_title <name>", "changjing_title", CommandCategory.System, 0, 1);
			//101
			this.RegisterCommandConfig("101", "特殊SE", "special_se <se_name> <num>", "101", CommandCategory.System, 1, 9);
		}

		// Token: 0x0600000A RID: 10 RVA: 0x00002884 File Offset: 0x00000A84
		private void RegisterCommandConfig(string name, string summary, string usage, string className, CommandCategory category, int minArgCount, int maxArgCount)
		{
			int count = this._commandConfigList.Count;
			CommandConfig item = default(CommandConfig);
			item.ID = count - 1;
			item.Name = name;
			item.Summary = summary;
			item.Usage = usage;
			item.ClassName = className;
			item.Category = category;
			item.MinArgCount = minArgCount;
			item.MaxArgCount = maxArgCount;
			this._commandConfigList.Add(item);
		}

		// Token: 0x0600000B RID: 11 RVA: 0x000028FC File Offset: 0x00000AFC
		public int GetCommandID(ref string name)
		{
			int count = this._commandConfigList.Count;
			for (int i = 0; i < count; i++)
			{
				if (this._commandConfigList[i].Name.Equals(name))
				{
					return i;
				}
			}
			return -1;
		}

		// Token: 0x0600000C RID: 12 RVA: 0x00002954 File Offset: 0x00000B54
		public string GetCommandName(int id)
		{
			string result;
			if (id >= this._commandConfigList.Count | id < 0)
			{
				result = null;
			}
			else
			{
				result = this._commandConfigList[id].Name;
			}
			return result;
		}

		// Token: 0x0600000D RID: 13 RVA: 0x0000299C File Offset: 0x00000B9C
		public string GetCommandSummary(int id)
		{
			string result;
			if (id >= this._commandConfigList.Count | id < 0)
			{
				result = null;
			}
			else
			{
				result = this._commandConfigList[id].Summary;
			}
			return result;
		}

		// Token: 0x0600000E RID: 14 RVA: 0x000029E4 File Offset: 0x00000BE4
		public string GetCommandUsage(int id)
		{
			string result;
			if (id >= this._commandConfigList.Count | id < 0)
			{
				result = null;
			}
			else
			{
				result = this._commandConfigList[id].Usage;
			}
			return result;
		}

		// Token: 0x0600000F RID: 15 RVA: 0x00002A2C File Offset: 0x00000C2C
		public string GetCommandClassName(int id)
		{
			string result;
			if (id >= this._commandConfigList.Count | id < 0)
			{
				result = null;
			}
			else
			{
				result = this._commandConfigList[id].ClassName;
			}
			return result;
		}

		// Token: 0x06000010 RID: 16 RVA: 0x00002A74 File Offset: 0x00000C74
		public CommandCategory GetCommandCategory(int id)
		{
			CommandCategory result;
			if (id >= this._commandConfigList.Count | id < 0)
			{
				result = CommandCategory.Non;
			}
			else
			{
				result = this._commandConfigList[id].Category;
			}
			return result;
		}

		// Token: 0x06000011 RID: 17 RVA: 0x00002ABC File Offset: 0x00000CBC
		public int GetCommandMinArgCount(int id)
		{
			int result;
			if (id >= this._commandConfigList.Count | id < 0)
			{
				result = 0;
			}
			else
			{
				result = this._commandConfigList[id].MinArgCount;
			}
			return result;
		}

		// Token: 0x06000012 RID: 18 RVA: 0x00002B04 File Offset: 0x00000D04
		public int GetCommandMaxArgCount(int id)
		{
			int result;
			if (id >= this._commandConfigList.Count | id < 0)
			{
				result = 0;
			}
			else
			{
				result = this._commandConfigList[id].MaxArgCount;
			}
			return result;
		}

		// Token: 0x06000013 RID: 19 RVA: 0x00002B4C File Offset: 0x00000D4C
		public int GetCommandConfigListCount()
		{
			return this._commandConfigList.Count;
		}

		// Token: 0x06000014 RID: 20 RVA: 0x00002B6C File Offset: 0x00000D6C
		public string GetSpacer()
		{
			return char.ToString(' ');
		}

		// Token: 0x04000011 RID: 17
		private List<CommandConfig> _commandConfigList;
	}
}
