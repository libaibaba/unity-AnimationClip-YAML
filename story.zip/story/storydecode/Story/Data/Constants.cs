﻿using System;

namespace Story.Data
{
	// Token: 0x02000007 RID: 7
	public static class Constants
	{
		// Token: 0x04000012 RID: 18
		public const int COMMAND_BYTE_SIZE = 2;

		// Token: 0x04000013 RID: 19
		public const char COMMAND_SPACER = ' ';

		// Token: 0x04000014 RID: 20
		public const int BIT_INVERSE_INTERVAL = 3;

		// Token: 0x04000015 RID: 21
		public const int BIN_BUFFER_SIZE = 61440;
	}
}
