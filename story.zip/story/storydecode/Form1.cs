﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using Story.Data;

namespace storydecode
{
	// Token: 0x02000008 RID: 8
	public partial class Form1 : Form
	{
		// Token: 0x06000016 RID: 22 RVA: 0x00002B8D File Offset: 0x00000D8D
		public Form1()
		{
			this.InitializeComponent();
		}

		// Token: 0x06000017 RID: 23 RVA: 0x00002BA8 File Offset: 0x00000DA8
		public void decodeRaw(string srcpath)
		{
			Parser parser = Parser.Create();
			byte[] byteData = File.ReadAllBytes(Path.GetFullPath(srcpath));
			string text = Path.GetFileNameWithoutExtension(srcpath);
			List<CommandStruct> list = parser.ConvertBinaryToCommandList(byteData);
			string text2 = "";
			foreach (CommandStruct commandStruct in list)
			{
				if (commandStruct.Name.Equals("title"))
				{
					text = text + " [" + commandStruct.Args[0] + "]-rawdata.txt";
					string text3 = new string(Path.GetInvalidFileNameChars()) + new string(Path.GetInvalidPathChars());
					string text4 = text3;
					for (int i = 0; i < text4.Length; i++)
					{
						text = text.Replace(text4[i].ToString(), string.Empty);
					}
				}
				text2 = text2 + commandStruct.Name + "\r\n";
				foreach (string str in commandStruct.Args)
				{
					text2 = text2 + str + "\r\n";
				}
				text2 = text2 + commandStruct.Category.ToString() + "\r\n" + "\r\n";
			}
			File.WriteAllText(string.Concat(new string[]
			{
				Path.GetDirectoryName(Path.GetFullPath(srcpath)),
				Path.DirectorySeparatorChar.ToString(),
				"",
				Path.DirectorySeparatorChar.ToString(),
				text
			}), text2);
		}

		// Token: 0x06000018 RID: 24 RVA: 0x00002DC0 File Offset: 0x00000FC0
		public void decodeDerestageStory(string srcpath)
		{
			try
			{
				Parser parser = Parser.Create();
				byte[] byteData = File.ReadAllBytes(Path.GetFullPath(srcpath));
				string text = Path.GetFileNameWithoutExtension(srcpath);
				List<CommandStruct> list = parser.ConvertBinaryToCommandList(byteData);
				string text2 = "";
				int num = 1;
				foreach (CommandStruct commandStruct in list)
				{
					if (commandStruct.Name.Equals("title"))
					{
						text = text + " [" + commandStruct.Args[0] + "].txt";
						string text3 = new string(Path.GetInvalidFileNameChars()) + new string(Path.GetInvalidPathChars());
						string text4 = text3;
						for (int i = 0; i < text4.Length; i++)
						{
							text = text.Replace(text4[i].ToString(), string.Empty);
						}
					}
					if (commandStruct.Name.Equals("print"))
					{
						int num2 = 1;
						foreach (string text5 in commandStruct.Args)
						{
							text2 = string.Concat(new string[]
							{
								text2,
								num.ToString(),
								".",
								num2.ToString(),
								" ",
								text5,
								"\r\n"
							});
							num2++;
						}
						num++;
						text2 += "\r\n";
					}
					if (commandStruct.Name.Equals("choice") || commandStruct.Name.Equals("outline") || commandStruct.Name.Equals("situation"))
					{
						int num2 = 1;
						foreach (string text5 in commandStruct.Args)
						{
							text2 = string.Concat(new string[]
							{
								text2,
								num.ToString(),
								".",
								num2.ToString(),
								" [" + commandStruct.Name + "] ",
								text5,
								"\r\n"
							});
							num2++;
						}
						num++;
						text2 += "\r\n";
					}
				}
				string text6 = string.Concat(new string[]
				{
					Path.GetDirectoryName(Path.GetFullPath(srcpath)),
					Path.DirectorySeparatorChar.ToString(),
					"out",
					Path.DirectorySeparatorChar.ToString(),
					text
				});
				try
				{
					Directory.CreateDirectory("out");
				}
				catch
				{
				}
				if (!File.Exists(text6))
				{
					File.WriteAllText(text6, text2);
				}
				else
				{
					File.WriteAllText(text6 + new Random().NextDouble().ToString().Replace(".", "_"), text2);
				}
			}
			catch
			{
			}
		}

		// Token: 0x06000019 RID: 25 RVA: 0x000031CC File Offset: 0x000013CC
		private void Form1_Load(object sender, EventArgs e)
		{
			//string[] commandLineArgs = Environment.GetCommandLineArgs();
			//string srcpath;
			//if (commandLineArgs.Length > 1)
			//{
			//	srcpath = commandLineArgs[1];
			//}
			//else
			//{
			//	OpenFileDialog openFileDialog = new OpenFileDialog();
			//	if (openFileDialog.ShowDialog().Equals(DialogResult.Cancel))
			//	{
			//		Environment.Exit(1);
			//	}
			//	srcpath = openFileDialog.FileName;
			//}
			//decodeRaw(srcpath);
			//Environment.Exit(0);
		}

		// Token: 0x0600001A RID: 26 RVA: 0x0000323C File Offset: 0x0000143C
		public void LoadFromPlaneFile(string srcpath)
		{
			string text = srcpath.Replace(".txt", ".bytes.txt");
			Parser.Create().ConvertStoryDataTextToBinary(ref srcpath, ref text);
		}

		// Token: 0x0600001B RID: 27 RVA: 0x0000326C File Offset: 0x0000146C
		public void BuildPlaneFile(string srcpath)
		{
			string[] source = new string[]
			{
				"title",
				"outline",
				"situation",
				"bgm",
				"vo",
				"fulltitle",
				"changjing_title"
			};
			string[] source2 = new string[]
			{
				"print",
				"log",
				"choice",
				"touch"
			};
			byte[] byteData = File.ReadAllBytes(srcpath);
			List<CommandStruct> list = Parser.Create().ConvertBinaryToCommandList(byteData);
			string text = "";
			string text9999 = "";
			bool flag = false;
			foreach (CommandStruct commandStruct in list)
			{
				if (!flag && commandStruct.Name == "print")
				{
					flag = true;
					text += commandStruct.Name;
					text = text + " \"" + commandStruct.Args[0] + "\"";
					for (int i = 1; i < commandStruct.Args.Count; i++)
					{
						text = text + " \"" + commandStruct.Args[i];
					}
				}
				else if (flag && commandStruct.Name == "print")
				{
					for (int i = 1; i < commandStruct.Args.Count; i++)
					{
						text += commandStruct.Args[i];
					}
				}
				if (commandStruct.Name == "touch")
				{
					flag = false;
					text += "\"\r\n";
				}
				if (commandStruct.Name == "log")
				{
					string text2 = text;
					text = string.Concat(new string[]
					{
						text2,
						commandStruct.Name,
						" ",
						commandStruct.Args[0],
						" "
					});
					for (int i = 1; i < commandStruct.Args.Count; i++)
					{
						text = text + "\"" + commandStruct.Args[i] + "\" ";
					}
					text += "\r\n";
				}
				if (commandStruct.Name == "choice")
				{
					string text2 = text;
					text = string.Concat(new string[]
					{
						text2,
						commandStruct.Name,
						" \"",
						commandStruct.Args[0],
						"\" "
					});
					for (int i = 1; i < commandStruct.Args.Count; i++)
					{
						text = text + commandStruct.Args[i] + " ";
					}
					text += "\r\n";
				}
				if (!flag && !source2.Contains(commandStruct.Name))
				{
					if (source.Contains(commandStruct.Name))
					{
						text += commandStruct.Name;
						for (int i = 0; i < commandStruct.Args.Count; i++)
						{
							text = text + " \"" + commandStruct.Args[i] + "\"";
						}
					}
					else
					{
						text += commandStruct.Name;
						for (int i = 0; i < commandStruct.Args.Count; i++)
						{
							text = text + " " + commandStruct.Args[i];
						}
					}
					text += "\r\n";
					
				}
				if (flag && !source2.Contains(commandStruct.Name))
				{
					if (source.Contains(commandStruct.Name))
					{
						text = text + "<" + commandStruct.Name;
						for (int i = 0; i < commandStruct.Args.Count; i++)
						{
							text = text + " \"" + commandStruct.Args[i] + "\"";
						}
						text += ">";
					}
					else
					{
						text = text + "<" + commandStruct.Name;
						for (int i = 0; i < commandStruct.Args.Count; i++)
						{
							text = text + " " + commandStruct.Args[i];
						}
						text += ">";
					}
				}


				text9999 += commandStruct.Name;
				for (int i = 0; i < commandStruct.Args.Count; i++)
				{
					text9999 = text9999 + " " + commandStruct.Args[i];
				}
				text9999 += "\r\n";

			}


			File.WriteAllText(srcpath + "-plane.txt", text);
			//File.WriteAllText(srcpath + "-planetext9999.txt", text9999);
		}

        private void decode_Click(object sender, EventArgs e)
        {
			OpenFileDialog openFileDialog = new OpenFileDialog();
			if (openFileDialog.ShowDialog().Equals(DialogResult.OK))
			{
				var srcpath = openFileDialog.FileName;
				BuildPlaneFile(srcpath);
			}
		}

        private void encode_Click(object sender, EventArgs e)
        {
			OpenFileDialog openFileDialog = new OpenFileDialog();
			if (openFileDialog.ShowDialog().Equals(DialogResult.OK))
			{
				var srcpath = openFileDialog.FileName;
				LoadFromPlaneFile(srcpath);
			}
		}
    }
}
