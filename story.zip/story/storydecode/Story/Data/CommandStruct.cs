﻿using System;
using System.Collections.Generic;

namespace Story.Data
{
	// Token: 0x02000004 RID: 4
	public struct CommandStruct
	{
		// Token: 0x0400000E RID: 14
		public string Name;

		// Token: 0x0400000F RID: 15
		public List<string> Args;

		// Token: 0x04000010 RID: 16
		public CommandCategory Category;
	}
}
